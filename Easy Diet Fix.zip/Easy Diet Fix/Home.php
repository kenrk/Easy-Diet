
<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Welcome!, ​Many Practices. One Intention., ​Join our powerful and efficient practices
with the best teachers, Contact Us">
    <meta name="description" content="">
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css" media="screen">
<link rel="stylesheet" href="css/Food-and-Exercise.css" media="screen">
    <meta name="generator" content="Nicepage 5.10.13, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Lobster:400|Oleo+Script:400,700">
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Easy Diet",
		"url": "/"
}</script>
    <meta name="theme-color" content="#374b43">
    <meta property="og:title" content="Home">
    <meta property="og:type" content="website">
    <link rel="canonical" href="/">
  <meta data-intl-tel-input-cdn-path="intlTelInput/"></head>
  <body class="u-body u-xl-mode" data-lang="en"><header class="u-clearfix u-header u-sticky u-sticky-c43b u-white u-header" id="sec-6cc5"><div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-align-center u-custom-font u-font-lobster u-text u-text-palette-3-base u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500">Easy Diet</h2>
        <nav class="u-menu u-menu-hamburger u-offcanvas u-menu-1" data-responsive-from="XL">
          <div class="menu-collapse" style="font-size: 1rem; letter-spacing: 0px; font-weight: 700; text-transform: uppercase;">
            <a class="u-button-style u-custom-border u-custom-border-color u-custom-borders u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-black u-text-hover-palette-2-base" href="#" style="font-size: calc(1em + 8px);">
              <svg class="u-svg-link" viewBox="0 0 24 24"><use xlink:href="#menu-hamburger"></use></svg>
              <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
              </g></svg>
            </a>
          </div>
          <div class="u-nav-container">
            <ul class="u-nav u-spacing-20 u-unstyled u-nav-1">
              <li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Food-and-Exercise.php" style="padding: 10px;">Food and Exercise</a>
              </li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Home.php" style="padding: 10px;">Home</a>
              </li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Sign-Up.php" style="padding: 10px;">Sign Up</a>
              </li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Log-In.php" style="padding: 10px;">Log In</a>
              </li></ul>
          </div>
          <div class="u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2">
                  <li class="u-nav-item"><a class="u-button-style u-nav-link" href="Food-and-Exercise.php">Food and Exercise</a>
                  </li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Home.php">Home</a>
                  </li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Sign-Up.php">Sign Up</a>
                  </li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Log-In.php">Log In</a>
                </li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
      </div></header>
      <section class="u-clearfix u-image u-section-1" id="sec-193e" data-image-width="1920" data-image-height="1200" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
      <div class="u-clearfix u-layout-wrap u-layout-wrap-1">
        <div class="u-gutter-0 u-layout">
          <div class="u-layout-row">
            <div class="u-align-left u-container-style u-layout-cell u-left-cell u-size-24-xl u-size-27-lg u-size-60-md u-size-60-sm u-size-60-xs u-layout-cell-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
              <div class="u-container-layout u-container-layout-1">
                <img class="u-image u-image-contain u-image-default u-image-1" src="images/bn.png" alt="" data-image-width="219" data-image-height="170" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
                <h1 class="u-align-center u-custom-font u-text u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500">Welcome!</h1>
                <p class="u-align-center u-text u-text-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="750"> Every human being should have a healthy life for living a better life. "Health is a state of complete harmony of the body, mind, and spirit." — B.K.S. Iyengar</p>
              </div>
            </div>
            <div class="u-align-left u-container-style u-image u-layout-cell u-right-cell u-size-33-lg u-size-36-xl u-size-60-md u-size-60-sm u-size-60-xs u-image-2" data-image-width="1468" data-image-height="1080" data-animation-name="customAnimationIn" data-animation-duration="1750" data-animation-delay="500">
              <div class="u-container-layout u-valign-middle u-container-layout-2"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="skrollable skrollable-between u-align-center u-clearfix u-image u-shading u-section-2" id="carousel_ddb9" src="" data-image-width="1280" data-image-height="675">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <h2 class="u-text u-text-default u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500">Where diet is no longer a burden</h2>
        <p class="u-custom-font u-font-montserrat u-large-text u-text u-text-variant u-text-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="250"> Heart disease remains the leading cause of death, and obesity rates have grown from 30.5% in 2000 to 42.4% in 2018. Adopting a ​​healthy diet can help combat both of these.</p>
      </div>
    </section>
    <section class="skrollable skrollable-between u-align-center u-clearfix u-image u-shading u-section-3" id="sec-635e" src="" data-image-width="1280" data-image-height="853">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <h2 class="u-text u-text-default u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500">What is EasyDiet exactly?</h2>
        <p class="u-custom-font u-font-montserrat u-large-text u-text u-text-variant u-text-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="250">A software that helps user maintain their body health for a desired target by programmed and personalized food recommendation and exercise.</p>
      </div>
    </section>
    <section class="skrollable skrollable-between u-align-center u-clearfix u-container-align-center u-image u-shading u-section-4" src="" id="sec-def6" data-image-width="1980" data-image-height="1223">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-align-center u-text u-text-default-lg u-text-default-xl u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="250"> Join now for your specially personalized diet and exercise!</h2>
        <a href="Sign-Up.php" class="u-active-white u-align-center u-border-2 u-border-active-white u-border-hover-white u-border-palette-3-base u-btn u-btn-round u-button-style u-hover-white u-palette-3-base u-radius-50 u-text-active-black u-text-hover-black u-btn-1" data-animation-name="customAnimationIn" data-animation-duration="1000" data-animation-delay="500">Register</a>
      </div>
    </section>
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-d5fc"><div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <p class="u-custom-font u-font-montserrat u-small-text u-text u-text-palette-3-base u-text-variant u-text-1">Easy Diet 2023</p>
      </div></footer>

      <script class="u-script" type="text/javascript" src="js/jquery-1.9.1.min.js" defer=""></script>
  <script class="u-script" type="text/javascript" src="js/app.js" defer=""></script>

</body></html>