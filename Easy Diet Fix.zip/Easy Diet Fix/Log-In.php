<?php
    // $servername='localhost';
    // $username='root';
    // $password='';
    // $dbname = "easydiet";
    // $conn=mysqli_connect($servername,$username,$password,"$dbname");
    //   if(!$conn){
    //       die('Could not Connect MySql Server:' .mysql_error());
    //     }
?>
<?php
include 'connection.php';
// if (session_status() == PHP_SESSION_NONE) {
//   session_start();
// }
// session_start();
if (isset($_SESSION["id_user"])) {
   header("Location: Food-and-Exercise.php");
   exit;
}

// include 'connection.php';


if (isset($_POST['login'])) {
$email    = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
$email_error = "Please Enter Valid Email ID";
}
if (strlen($password) < 6) {
$password_error = "Password must be minimum of 6 characters";
}
$result = mysqli_query($conn, "SELECT * FROM user  WHERE email = '" . $email . "' and password = '" . md5($password) . "'");
if ($row = mysqli_fetch_array($result)) {
$_SESSION['id_user']     = $row['id_user'];
// $_SESSION['user_name']   = $row['name'];
// $_SESSION['user_mobile'] = $row['mobile'];
// $_SESSION['user_email']  = $row['email'];
header("Location: Food-and-Exercise.php");
} else {
$error_message = "Incorrect Email or Password!!!";
}
}

// $conn->close();
// if (isset($_POST['login'])) {
//   $email = trim($_POST['email']);
//   $password = trim($_POST['password']);
//   $passwordHash = md5($password);

//   $sql = "SELECT * FROM user WHERE email = ? AND password = ?";
//   $stmt = $conn->prepare($sql);

//   if ($stmt) {
//   $stmt->bind_param("ss", $email, $passwordHash);
//   $stmt->execute();
//   $result = $stmt->get_result();
//   $user = $result->fetch_assoc();

//   if ($user) {
//     // Login successful
//     $_SESSION["id_user"] = $user["id_user"];
//     header("Location: Food-and-Exercise.php");
//     exit;
// } else {
//     // Invalid email or password
//     echo "<div class='alert alert-danger'>Invalid email or password</div>";
// }
// $stmt->close();
// } else {
//   // Handle the case when $stmt is not defined
//   echo "<div class='alert alert-danger'>An error occurred during the login process</div>";
// }
// }
?>
<!DOCTYPE html>
<html style="font-size: 16px;" lang="en">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta name="keywords" content="Easy Diet">
  <meta name="description" content="">
  <title>Log In</title>
  <link rel="stylesheet" href="css/style.css" media="screen">
  <link rel="stylesheet" href="css/Food-and-Exercise.css" media="screen">
  <meta name="generator" content="Nicepage 5.10.13, nicepage.com">
  <meta name="referrer" content="origin">
  <link id="u-theme-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
  <link id="u-page-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Lobster:400">
  <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "Organization",
      "name": "Easy Diet"
    }
  </script>
  <meta name="theme-color" content="#374b43">
  <meta property="og:title" content="Log In">
  <meta property="og:type" content="website">
  <meta data-intl-tel-input-cdn-path="intlTelInput/">
</head>

<body class="u-body u-xl-mode" data-lang="en">
  <header class="u-clearfix u-header u-sticky u-sticky-c43b u-white u-header" id="sec-6cc5">
    <div class="u-clearfix u-sheet u-sheet-1">
      <h2 class="u-align-center u-custom-font u-font-lobster u-text u-text-palette-3-base u-text-1"
        data-animation-name="customAnimationIn" data-animation-duration="1500">Easy Diet</h2>
      <nav class="u-menu u-menu-hamburger u-offcanvas u-menu-1" data-responsive-from="XL">
        <div class="menu-collapse"
          style="font-size: 1rem; letter-spacing: 0px; font-weight: 700; text-transform: uppercase;">
          <a class="u-button-style u-custom-border u-custom-border-color u-custom-borders u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-black u-text-hover-palette-2-base"
            href="#" style="font-size: calc(1em + 8px);">
            <svg class="u-svg-link" viewBox="0 0 24 24">
              <use xlink:href="#menu-hamburger"></use>
            </svg>
            <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px"
              xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg">
              <g>
                <rect y="1" width="16" height="2"></rect>
                <rect y="7" width="16" height="2"></rect>
                <rect y="13" width="16" height="2"></rect>
              </g>
            </svg>
          </a>
        </div>
        <div class="u-nav-container">
          <ul class="u-nav u-spacing-20 u-unstyled u-nav-1">
            <li class="u-nav-item"><a
                class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base"
                href="Food-and-Exercise.php" style="padding: 10px;">Food and Exercise</a>
            </li>
            <li class="u-nav-item"><a
                class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base"
                href="Home.php" style="padding: 10px;">Home</a>
            </li>
            <li class="u-nav-item"><a
                class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base"
                href="Sign-Up.php" style="padding: 10px;">Sign Up</a>
            </li>
            <li class="u-nav-item"><a
                class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base"
                href="Log-In.php" style="padding: 10px;">Log In</a>
            </li>
          </ul>
        </div>
        <div class="u-nav-container-collapse">
          <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
            <div class="u-inner-container-layout u-sidenav-overflow">
              <div class="u-menu-close"></div>
              <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2">
                <li class="u-nav-item"><a class="u-button-style u-nav-link" href="Food-and-Exercise.php">Food and
                    Exercise</a>
                </li>
                <li class="u-nav-item"><a class="u-button-style u-nav-link" href="Home.php">Home</a>
                </li>
                <li class="u-nav-item"><a class="u-button-style u-nav-link" href="Sign-Up.php">Sign Up</a>
                </li>
                <li class="u-nav-item"><a class="u-button-style u-nav-link" href="Log-In.php">Log In</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
        </div>
      </nav>
    </div>
  </header>
  <section class="u-align-center u-clearfix u-palette-3-base u-section-1" id="sec-1c4c">
    <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
      <div class="u-clearfix u-layout-wrap u-layout-wrap-1">
        <div class="u-layout">
          <div class="u-layout-row">
            <div class="u-align-left u-container-style u-layout-cell u-size-60 u-white u-layout-cell-1">
              <div class="u-container-layout u-container-layout-1">
                <h2 class="u-align-left u-custom-font u-font-montserrat u-text u-text-1">Log In</h2>
                <div
                  class="u-align-left u-expanded-width-lg u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-form u-form-1">
                  <span class="text-danger"><?php if (isset($error_message)) echo $error_message; ?></span>
                  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"
                    class="u-clearfix u-form-spacing-28 u-form-vertical u-inner-form" style="padding: 0px;"
                    method="post">
                    <div class="u-form-email u-form-group u-label-none">
                      <input type="email" placeholder="Enter your email" name="email"
                        class="u-border-none u-grey-5 u-input u-input-rectangle u-radius-7 u-input-1">
                      <span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
                    </div>
                    <div class="u-form-group u-label-none">
                      <input type="password" placeholder="Enter your password" name="password"
                        class="u-border-none u-grey-5 u-input u-input-rectangle u-radius-7 u-input-2">
                      <span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
                    </div>
                    <div class="u-align-right u-form-group u-form-submit u-label-none">
                      <p class="message">Not registered? <a href="Sign-up.php">Create an account</a></p>
                      <button type="submit" class="btn" name="login" value="Login">Submit</button>
                    </div>
                    <!-- <div class="u-form-send-message u-form-send-success" wfd-invisible="true"> Login successfully </div>
                      <div class="u-form-send-error u-form-send-message" wfd-invisible="true"> Unable to login </div> -->
                    <!-- <input type="hidden" value="" name="recaptchaResponse" wfd-invisible="true">
                      <input type="hidden" name="formServices" value="892a97b5427b545832e368c695f430e8"> -->
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-d5fc">
    <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
      <p class="u-custom-font u-font-montserrat u-small-text u-text u-text-palette-3-base u-text-variant u-text-1">Easy
        Diet 2023</p>
    </div>
  </footer>
  <!-- 
  <script class="u-script" type="text/javascript" src="js/jquery-1.9.1.min.js" defer=""></script>
  <script class="u-script" type="text/javascript" src="js/app.js" defer=""></script> -->

</body>

</html>