<?php 

include 'connection.php';

if (isset($_POST["register"])) {
  $name = trim($_POST["name"]);
  $email = trim($_POST["email"]);
  $password = trim($_POST["password"]);
  $gender = trim($_POST["gender"]);
  $age = trim($_POST["age"]);
  $weight = trim($_POST["weight"]);
  $target_weight = trim($_POST["target_weight"]);

  $passwordHash = md5($password);
 
$sql = "INSERT INTO user (name, email, password, gender, age, weight, target_weight) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss",$name, $email, $passwordHash, $gender, $age, $weight, $target_weight);
    $stmt->execute();
    if ($stmt->affected_rows > 0) {
        header("Location: Log-in.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $stmt->close();
}

?>
<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Easy Diet">
    <meta name="description" content="">
    <title>Sign Up</title>
    <link rel="stylesheet" href="css/style.css" media="screen">
<link rel="stylesheet" href="css/Sign-Up.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery-1.9.1.min.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="app.js" defer=""></script>
    <meta name="generator" content="Nicepage 5.10.13, nicepage.com">
    <meta name="referrer" content="origin">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Lobster:400">
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Easy Diet"
}</script>
    <meta name="theme-color" content="#374b43">
    <meta property="og:title" content="Sign Up">
    <meta property="og:type" content="website">
  <meta data-intl-tel-input-cdn-path="intlTelInput/"></head>
  <body class="u-body u-xl-mode" data-lang="en"><header class="u-clearfix u-header u-sticky u-sticky-c43b u-white u-header" id="sec-6cc5"><div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-align-center u-custom-font u-font-lobster u-text u-text-palette-3-base u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500">Easy Diet</h2>
        <nav class="u-menu u-menu-hamburger u-offcanvas u-menu-1" data-responsive-from="XL">
          <div class="menu-collapse" style="font-size: 1rem; letter-spacing: 0px; font-weight: 700; text-transform: uppercase;">
            <a class="u-button-style u-custom-border u-custom-border-color u-custom-borders u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-black u-text-hover-palette-2-base" href="#" style="font-size: calc(1em + 8px);">
              <svg class="u-svg-link" viewBox="0 0 24 24"><use xlink:href="#menu-hamburger"></use></svg>
              <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
            </a>
          </div>
          <div class="u-nav-container">
            <ul class="u-nav u-spacing-20 u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Food-and-Exercise.html" style="padding: 10px;">Food and Exercise</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Home.php" style="padding: 10px;">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Sign-Up.php" style="padding: 10px;">Sign Up</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Log-In.php" style="padding: 10px;">Log In</a>
</li></ul>
          </div>
          <div class="u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Food-and-Exercise.php">Food and Exercise</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Home.php">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Sign-Up.php">Sign Up</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Log-In.php">Log In</a>
</li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
      </div></header>
    <section class="u-align-center u-clearfix u-palette-3-base u-section-1" id="sec-598e">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <div class="u-clearfix u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-row">
              <div class="u-align-left u-container-style u-layout-cell u-size-60 u-white u-layout-cell-1">
                <div class="u-container-layout u-container-layout-1">
                  <h2 class="u-align-left u-custom-font u-font-montserrat u-text u-text-1">Sign Up</h2>
                  <div class="u-align-left u-form u-form-1">
                    <form action="Sign-Up.php" class="u-clearfix u-form-spacing-28 u-form-vertical u-inner-form" style="padding: 0px;" method="post">
                      <div class="u-form-group u-form-name u-label-top u-form-group-1">
                        <label for="name" class="u-label">Name</label>
                        <input type="text" placeholder="Enter your name" id="name" name="name" class="u-border-none u-grey-5 u-input u-input-rectangle u-radius-7 u-input-1" required="">
                      </div>
                      <div class="u-form-email u-form-group u-label-top">
                        <label for="email" class="u-label" wfd-invisible="true">Email</label>
                        <input type="email" placeholder="Enter your email" id="email" name="email" class="u-border-none u-grey-5 u-input u-input-rectangle u-radius-7 u-input-2" required="required">
                      </div>
                      <div class="u-form-group u-label-top">
                        <label for="password" class="u-label" wfd-invisible="true">Password</label>
                        <input type="password" placeholder="Enter your password" id="password" name="password" class="u-border-none u-grey-5 u-input u-input-rectangle u-radius-7 u-input-3" required="required">
                      </div>
                      <div class="u-form-group u-form-select u-label-top u-form-group-4">
                        <label for="Gender" class="u-label">Gender</label>
                        <div class="u-form-select-wrapper">
                          <select id="select-c0d4" name="select" class="u-border-none u-grey-5 u-input u-input-rectangle u-radius-7 u-input-4">
                            <option value="Male" data-calc="">Male</option>
                            <option value="Female" data-calc="">Female</option>
                          </select>
                          <svg class="u-caret u-caret-svg" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" style="fill:currentColor;" xml:space="preserve"><polygon class="st0" points="8,12 2,4 14,4 "></polygon></svg>
                        </div>
                      </div>
                      <div class="u-form-group u-form-number u-form-number-layout-number u-form-partition-factor-3 u-label-top u-form-group-5">
                        <label for="number-d5c2" class="u-label">Age</label>
                        <div class="u-input-row" data-value="0">
                          <input value="0" min="0" max="100" step="1" type="number" placeholder="" id="age" name="age" class="u-border-none u-grey-5 u-input u-input-rectangle u-radius-7 u-text-black u-input-5">
                        </div>
                      </div>
                      <div class="u-form-group u-form-number u-form-number-layout-number u-form-partition-factor-3 u-label-top u-form-group-6">
                        <label for="number-3e2b" class="u-label">Weight</label>
                        <div class="u-input-row" data-value="0">
                          <input value="0" min="0" max="100" step="1" type="number" placeholder="" id="weight" name="weight" class="u-border-none u-grey-5 u-input u-input-rectangle u-radius-7 u-text-black u-input-6">
                        </div>
                      </div>
                      <div class="u-form-group u-form-number u-form-number-layout-number u-form-partition-factor-3 u-label-top u-form-group-7">
                        <label for="number-26a8" class="u-label">Target Weight</label>
                        <div class="u-input-row" data-value="0">
                          <input value="0" min="0" max="100" step="1" type="number" placeholder="" id="tweight" name="tweight" class="u-border-none u-grey-5 u-input u-input-rectangle u-radius-7 u-text-black u-input-7">
                        </div>
                      </div>
                      <div class="u-align-right u-form-group u-form-submit u-label-top">
                        <a href="#" class="u-active-black u-border-none u-btn u-btn-round u-btn-submit u-button-style u-hover-black u-palette-3-base u-radius-7 u-text-active-white u-text-body-alt-color u-text-hover-white u-btn-1">Submit</a>
                        <input type="submit" name="register" value="submit" class="u-form-control-hidden" wfd-invisible="true">
                      </div>
                      <div class="u-form-send-message u-form-send-success" wfd-invisible="true"> Signup successfully </div>
                      <div class="u-form-send-error u-form-send-message" wfd-invisible="true"> Unable to signup </div>
                      <input type="hidden" value="" name="recaptchaResponse" wfd-invisible="true">
                      <input type="hidden" name="formServices" value="892a97b5427b545832e368c695f430e8">
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-d5fc"><div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <p class="u-custom-font u-font-montserrat u-small-text u-text u-text-palette-3-base u-text-variant u-text-1">Easy Diet 2023</p>
      </div></footer>
</body></html>