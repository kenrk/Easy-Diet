<?php 
// session_start();
session_start();
//cek adakah session,user sudah login atau belum/kalau gada belum login jadi diarahkan ke login.php
if( !isset($_SESSION["id_user"])) {
header("Location: Log-in.php");
exit;

}
?>
<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Easy Diet, Food for you">
    <meta name="description" content="">
    <title>Food and Exercise</title>
    <link rel="stylesheet" href="css/style.css" media="screen">
<link rel="stylesheet" href="css/Food-and-Exercise.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery-1.9.1.min.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="app.js" defer=""></script>
    <meta name="generator" content="Nicepage 5.10.13, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Lobster:400">
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Easy Diet"
}</script>
<meta name="theme-color" content="#374b43">
    <meta property="og:title" content="Home">
    <meta property="og:type" content="website">
    <link rel="canonical" href="/">
  <meta data-intl-tel-input-cdn-path="intlTelInput/"></head>
  <body data-home-page="https://website5033335.nicepage.io/Home.html?version=573e32ee-2c6b-4517-9da9-8e33101363ad" data-home-page-title="Home" class="u-body u-xl-mode" data-lang="en"><header class="u-clearfix u-header u-sticky u-sticky-c43b u-white u-header" id="sec-6cc5"><div class="u-clearfix u-sheet u-sheet-1">
  <h2 class="u-align-center u-custom-font u-font-lobster u-text u-text-palette-3-base u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500">Easy Diet</h2>
        <nav class="u-menu u-menu-hamburger u-offcanvas u-menu-1" data-responsive-from="XL">
          <div class="menu-collapse" style="font-size: 1rem; letter-spacing: 0px; font-weight: 700; text-transform: uppercase;">
            <a class="u-button-style u-custom-border u-custom-border-color u-custom-borders u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-black u-text-hover-palette-2-base" href="#" style="font-size: calc(1em + 8px);">
              <svg class="u-svg-link" viewBox="0 0 24 24"><use xlink:href="#menu-hamburger"></use></svg>
              <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
            </a>
          </div>
            </a>
          </div>
          <div class="u-nav-container">
            <ul class="u-nav u-spacing-20 u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Food-and-Exercise.php" style="padding: 10px;">Food and Exercise</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-grey-90 u-text-hover-palette-3-base" href="Home.php" style="padding: 10px;">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-3-base u-text-danger u-text-hover-palette-3-base" href="logout.php" style="padding: 10px;">Log Out</a>
</li></ul>
          </div>
          <div class="u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Food-and-Exercise.php">Food and Exercise</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Home.php">Home</a>

</li><li class="u-nav-item"><a class="u-button-style u-nav-link text-danger-90" href="logout.php">Log Out</a>
</li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
      </div></header>
    <section class="u-align-center u-clearfix u-container-align-center u-image u-section-1" id="sec-24fa" data-image-width="1980" data-image-height="1600">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-align-center u-text u-text-default u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500">Food for you</h2>
        <div class="u-expanded-width u-list u-list-1">
          <div class="u-repeater u-repeater-1">
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-1">
                <h4 class="u-align-center u-text u-text-2">caesar salad</h4>
                <img class="u-expanded-width u-image u-image-default u-image-1" alt="" data-image-width="784" data-image-height="980" src="images/Chopped-Salad-008-784x980.webp">
                <p class="u-align-center u-text u-text-3">17 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-2">
                <h4 class="u-align-center u-text u-text-4">cereal<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-2" alt="" data-image-width="1200" data-image-height="1023" src="images/RS5342_179139232-scr1.jpg">
                <p class="u-align-center u-text u-text-5">124 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-3" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-3">
                <h4 class="u-align-center u-text u-text-6">egg and toast</h4>
                <img class="u-expanded-width u-image u-image-default u-image-3" alt="" data-image-width="800" data-image-height="800" src="images/gorgeous-egg-on-toast.jpeg">
                <p class="u-align-center u-text u-text-7">200 cal (1 egg 1 toast)</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-4" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-4">
                <h4 class="u-align-center u-text u-text-8">salmon</h4>
                <img class="u-expanded-width u-image u-image-default u-image-4" alt="" data-image-width="2560" data-image-height="1651" src="images/raw-salmon-slice-salmon-sashimi-1-scaled.jpg">
                <p class="u-align-center u-text u-text-9"> 232&nbsp;cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-5" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-5">
                <h4 class="u-align-center u-text u-text-10">broccoli</h4>
                <img class="u-expanded-width u-image u-image-default u-image-5" alt="" data-image-width="3888" data-image-height="2592" src="images/img_0305.jpg">
                <p class="u-align-center u-text u-text-11">34 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-6" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-6">
                <h4 class="u-align-center u-text u-text-12">steak<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-6" alt="" data-image-width="1800" data-image-height="1200" src="images/How-to-Cook-Steak-to-Perfection-5-Easy-Methods.jpg">
                <p class="u-align-center u-text u-text-13">211 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-7" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-7">
                <h4 class="u-align-center u-text u-text-14">fish and chips<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-7" alt="" data-image-width="3000" data-image-height="2000" src="images/R1.jfif">
                <p class="u-align-center u-text u-text-15">213 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-8" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-8">
                <h4 class="u-align-center u-text u-text-16">steamed chicken<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-8" alt="" data-image-width="474" data-image-height="474" src="images/OIP.jfif">
                <p class="u-align-center u-text u-text-17">168 cal</p>
              </div>
            </div>
          </div>
        </div>
        <p class="u-align-center u-custom-font u-font-montserrat u-text u-text-default u-text-18">*calories per 100 grams</p>
      </div>
    </section>
    <section class="u-align-center u-clearfix u-container-align-center u-image u-section-2" id="sec-1239" data-image-width="1980" data-image-height="1600">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-align-center u-text u-text-default u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500">Exercises for you</h2>
        <div class="u-expanded-width u-list u-list-1">
          <div class="u-repeater u-repeater-1">
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-1">
                <h4 class="u-align-center u-text u-text-2">walking<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-1" alt="" data-image-width="500" data-image-height="333" src="images/pexels-photo-951886.jpeg">
                <p class="u-align-center u-text u-text-3">45 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-2">
                <h4 class="u-align-center u-text u-text-4">jogging<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-2" alt="" data-image-width="474" data-image-height="315" src="images/OIP1.jfif">
                <p class="u-align-center u-text u-text-5">80 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-3" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-3">
                <h4 class="u-align-center u-text u-text-6">running</h4>
                <img class="u-expanded-width u-image u-image-default u-image-3" alt="" data-image-width="1200" data-image-height="628" src="images/Runner-training-on-running-track-1200x628-facebook.webp">
                <p class="u-align-center u-text u-text-7">132 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-4" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-4">
                <h4 class="u-align-center u-text u-text-8"> cycling</h4>
                <img class="u-expanded-width u-image u-image-default u-image-4" alt="" data-image-width="3474" data-image-height="2332" src="images/R3.jfif">
                <p class="u-align-center u-text u-text-9">122 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-5" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-5">
                <h4 class="u-align-center u-text u-text-10">swimming<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-5" alt="" data-image-width="5004" data-image-height="3336" src="images/R4.jfif">
                <p class="u-align-center u-text u-text-11">142 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-6" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-6">
                <h4 class="u-align-center u-text u-text-12">jumping rope<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-6" alt="" data-image-width="1000" data-image-height="1000" src="images/Jump-Rope.jpg">
                <p class="u-align-center u-text u-text-13">121 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-7" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-7">
                <h4 class="u-align-center u-text u-text-14">burpee<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-7" alt="" data-image-width="1456" data-image-height="1456" src="images/R2.jfif">
                <p class="u-align-center u-text u-text-15">125 cal</p>
              </div>
            </div>
            <div class="u-align-left u-container-align-center u-container-style u-list-item u-repeater-item u-shape-rectangle u-video-cover u-white u-list-item-8" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-container-layout-8">
                <h4 class="u-align-center u-text u-text-16">Yoga<br>
                </h4>
                <img class="u-expanded-width u-image u-image-default u-image-8" alt="" data-image-width="909" data-image-height="909" src="images/566.jpg">
                <p class="u-align-center u-text u-text-17">66 cal</p>
              </div>
            </div>
          </div>
        </div>
        <p class="u-align-center u-custom-font u-font-montserrat u-text u-text-default u-text-18">*calories per 10 minutes</p>
      </div>
    </section>
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-d5fc"><div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <p class="u-custom-font u-font-montserrat u-small-text u-text u-text-palette-3-base u-text-variant u-text-1">Easy Diet 2023</p>
      </div></footer>

      <script class="u-script" type="text/javascript" src="js/jquery-1.9.1.min.js" defer=""></script>
  <script class="u-script" type="text/javascript" src="js/app.js" defer=""></script>>

</body></html>