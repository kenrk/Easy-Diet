<?php 
function query($query){
  global $conn;
  $result = mysqli_query($conn, $query);
  $rows = [];
  while ( $row = mysqli_fetch_assoc($result)){

      $rows[] = $row;
  }
  return $rows;
}

function registrasi($data){
  global $conn;
  $name = strtolower(stripsLashes($data["name"]));
  $email = mysqli_real_escape_string($conn,$data["email"]); //function =memungkinkan si users memasukkan password ada tanda kutip dan tanda kutip dimasukkan ke database secara aman
  $password = mysqli_real_escape_string($conn,$data["password"]);
  $password =  md5($password);
  $gender = $data["gender"];
  $age = strtolower(stripsLashes($data["age"]));
  $weight = strtolower(stripsLashes($data["weight"]));
  $target_weight = $data["target_weight"];

  //cek username sudah ada atau belum
 $result =
  mysqli_query ($conn, "SELECT email FROM user WHERE email = '$email'");
  if (mysqli_fetch_assoc($result)){
      echo "<script>
      alert('Email sudah terdaftar')
      </script>
      ";
   
  }
  
  
//enkripsi password
// $password = password_hash($password, PASSWORD_DEFAULT);

//tambahkan user baru ke database
mysqli_query($conn, "INSERT INTO user VALUES('', '$name', '$email', '$password', '$gender', '$age', '$weight'
,'$target_weight')");
return mysqli_affected_rows($conn);//untuk menghasilkan angka 1 bila berhasil,-1 jika gagal
}
?>