<?php
session_start();
$hostname = "localhost";
$username = "root";
$password = "";
$database = "easydiet";

// Create a new mysqli connection
$conn = new mysqli($hostname, $username, $password, $database);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>